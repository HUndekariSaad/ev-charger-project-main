import { create } from 'zustand'

 export const bookStore = create((set) => ({
  bears: 0,
  isLoggedInUser: false,
  setLogIn: () => set((state) => ({...state, isLoggedInUser: true})),
  setLogOut: () => set((state) => ({...state, isLoggedInUser: false})),

  increasePopulation: () => set((state) => ({ bears: state.bears + 1 })),
  removeAllBears: () => set({ bears: 0 }),
  updateBears: (newBears) => set({ bears: newBears }),
}))


