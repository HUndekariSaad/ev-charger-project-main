import React, { useState } from 'react';
import Login from '../components/Login.js';
import { Link,useNavigate  } from 'react-router-dom';
import TripPlanerForm from '../components/TripPlanerForm.js';

const TripPlaner = ({ isOpenTripPlaner, onCloseTripPlaner }) => {

    const [isModalOpen, setModalOpen] = useState(false);
    const [isModalOpen2, setModalOpen2] = useState(false);
    const [isMenuVisible2, setIsMenuVisible2] = useState(false);
  
    const navigate = useNavigate(); 

   

    const handleLoginClick = (e) => {
        setModalOpen(true);
        setIsMenuVisible2(false);
        e.stopPropagation();
    }

    const handleTripFormClick = (e) => {
        setModalOpen2(true);
        // setIsMenuVisible3(false);
        e.stopPropagation();
    }




 

    const handleGuideButtonClick = () => {
        window.open('/trip-planner-guide', '_blank'); // Open in a new tab
    };

    if (!isOpenTripPlaner) return null;

    return (
        <div>
        <div style={styles.modalOverlay} onClick={onCloseTripPlaner}>
            <div style={styles.container} onClick={(e) => e.stopPropagation()}>
                <div style={styles.header}>
                    <h2 style={styles.title}>Welcome to the EV Trip Planner</h2>
                    <button style={styles.closeButton} onClick={onCloseTripPlaner}>
                        &times;
                    </button>
                </div>
                <div style={styles.textContainer}>
                    <div style={{ padding: '38px' }}>
                       <h4>Plan your next trip with the PlugShare Trip Planner!  <span 
        style={styles.link} 
        onClick={() => handleLoginClick(true)} 
        role="button" 
        tabIndex={0} // Makes it accessible
    >
       ( Free EV Charger account required)
    </span></h4>
                        <h3>Join the largest EV community. Fast and Free.</h3>
                        <h3>Exclusive Member Benefits:</h3>
                        <ul style={styles.benefitsList}>
                            <li>Add your voice. Leave reviews, tips, photos, and more</li>
                            <li>Add your vehicle. Automatically see only compatible chargers</li>
                            <li>Exclusive access to Trip Planner: smart routing for long journeys</li>
                            <li>Alerts when chargers open near you (app only)</li>
                            <li>Driver to driver messaging (app only)</li>
                        </ul>
                        <div style={styles.buttonContainer}>
    <button style={styles.button}  onClick={() => handleGuideButtonClick()}  >
        Trip Planner Guide & Tips.
    </button>
    <div style={styles.helperText}>
        For more usage instructions, click the help icon to view the   <Link  target="_blank" to="/trip-planner-guide" style={styles.link}>
            Trip Planner Guide & Tips
        </Link>
    </div>
</div>
                        <div style={styles.signInContainer}>
                        {localStorage.getItem('token') ? (
        <button style={styles.signInButton} onClick={() => handleTripFormClick()}>
            Start Trip Planner
        </button>
    ) : (
        <button style={styles.signInButton} onClick={() => handleLoginClick(true)}>
            Sign In or Register Now!
        </button>
    )}
                        </div>
                    </div>
                </div>
            </div>
        </div>

        
        <Login 
        isOpen={isModalOpen} 
        onClose={() => {
            setModalOpen(false);
            onCloseTripPlaner(); // Close the TripPlaner when Login modal is closed
        }} 
      />
        </div>

       
    );
};

export default TripPlaner;

// Styles remain unchanged
const styles = {
    modalOverlay: {
        position: 'fixed',
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        backgroundColor: 'rgba(0, 0, 0, 0.5)',
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        zIndex: 9999,
    },
    container: {
        display: 'flex',
        flexDirection: 'column', 
        width: '800px',
        height: '500px',
        backgroundColor: '#fff',
        borderRadius: '8px',
        overflow: 'hidden',
    },
    header: {
        display: 'flex',
        justifyContent: 'space-between', // Space out the title and close button
        alignItems: 'center',
        backgroundColor: '#f1f1f1',
        padding: '10px 20px',
        borderBottom: '1px solid #ccc',
    },
    title: {
        margin: 0,
        fontSize: '20px',
        color: '#333',
    },
    closeButton: {
        background: 'none',
        border: 'none',
        fontSize: '24px',
        cursor: 'pointer',
        color: '#333',
    },
    textContainer: {
        flex: 1,
        display: 'flex',
        flexDirection: 'column',
        justifyContent: 'center',
        // color: "black", // Change to black for readability
        backgroundColor: "white",
    },
    benefitsList: {
        listStyleType: 'none',
        paddingLeft: '0',
    },
    buttonContainer: {
        display: 'grid', // Use grid layout
        gridTemplateColumns: 'auto 1fr', // Auto width for button, rest for text
        alignItems: 'center', // Center vertically
        marginTop: '20px',
    },
    button: {
        padding: '10px 20px',
        borderRadius: '4px',
        border: 'none',
        backgroundColor: '#738677',
        color: '#fff',
        fontSize: '16px',
        cursor: 'pointer',
    },
    helperText: {
        fontSize: '12px',
        marginLeft: '10px',
        // color: '#ccc',
    },
    signInContainer: {
        marginTop: '20px',
        textAlign: 'center',
    },
    signInText: {
        marginBottom: '10px',
    },
    signInButton: {
        padding: '10px 20px',
        borderRadius: '4px',
        border: 'none',
        backgroundColor: '#007BFF', // Bootstrap primary color
        color: '#fff',
        fontSize: '16px',
        cursor: 'pointer',
        marginRight: '10px',
    },
    orText: {
        margin: '10px 0',
    },
    registerButton: {
        padding: '10px 20px',
        borderRadius: '4px',
        border: 'none',
        backgroundColor: '#28A745', // Bootstrap success color
        color: '#fff',
        fontSize: '16px',
        cursor: 'pointer',
    },
    link: {
        color: '#007BFF', // Link color
        textDecoration: 'underline', // Underline to indicate it's a link
        cursor: 'pointer', // Change cursor to pointer
    },


};
