

import './styles.css';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Login from "./components/Login.js"
import Home from "./Home.js";
import Business from './components/Business.js';
import Map from './Maps.js'
import TripPlannerGuide from './components/TripPlannerGuide.js';


function App() {
  return (
<Router>
      <Routes>
        <Route path="/login" element={ <Login/> }></Route>
        {/* <Route path="/" element={ <Home/> }></Route> */}
        <Route path="/" element={ <Home/> }></Route>
        <Route path="/Map" element={ <Map /> }></Route>
        <Route path="/trip-planner-guide" element={ <TripPlannerGuide />}  />
      </Routes>
  </Router>

    
  );
}

export default App;








