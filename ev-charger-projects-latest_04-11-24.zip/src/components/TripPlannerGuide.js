import React from 'react'

import  image_1 from './../asset/img/trip_planner_6.png'
import  image_2 from './../asset/img/trip_planner_5.png'

const TripPlannerGuide = () => {
  return (
    <div style={styles.container}>
    <h1 style={styles.title}>Trip Planner Guide & Tips</h1>
    <p style={styles.paragraph}>
        We've launched an all-new help center to better serve your needs, which includes updated Trip Planner resources. Feel free to check out our guide:
    </p>
    
    <p style={styles.paragraph}>
        Trip Planner is back in action! This newly rebuilt Trip Planner has a lot of new requested features, so we'll go through how to use them here. Please send any feedback or bug reports by clicking the Menu dropdown and Submit Feedback.
    </p>

    <p style={styles.notice}>
        Notice: To create or edit trips, we require your screen to be a minimum of 1200px wide.
    </p>

    <p style={styles.paragraph}>
        This is the optimal minimum resolution because with the Trip Planner bar fixed to the right, you need enough real estate to view and browse the map, while also looking at location details on the left.
    </p>

    <p style={styles.paragraph}>
        We have made updates to make the Trip Planner responsive for mobile & tablet devices, so you can still view your previously planned trips on the go.
    </p>
    <img src={image_1} alt="Trip Planner Visual" style={styles.image} />


    <p style={styles.paragraph}>
        To begin, please add your Starting Location and Destination.
    </p>

    <p style={styles.paragraph}>
        The map will automatically route your driving directions and populate the map with charging stations along your route.
    </p>

    <p style={styles.paragraph}>
        Please keep in mind, your filters still apply! You may open up your filter settings and update them to refresh the map markers as per usual.
    </p>
    <img src={image_2} alt="Trip Planner Visual" style={{ height: '400px' }} />
    
</div>

  )
}

export default TripPlannerGuide


const styles = {
    container: {
        padding: '20px',
        // maxWidth: '800px',
        margin: '0px 270px 0px 66px',
        backgroundColor: '#f9f9f9',
        borderRadius: '8px',
    },
    title: {
        fontSize: '24px',
        marginBottom: '20px',
        color: '#333',
    },
    paragraph: {
        marginBottom: '15px',
        lineHeight: '1.6',
        color: '#555',
    },
    notice: {
        margin: '15px 0',
        fontWeight: 'bold',
        color: '#d9534f', // Bootstrap danger color
    },
};
