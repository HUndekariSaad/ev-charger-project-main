import React, { useState } from 'react';

const TripPlanerForm = ({ isOpenTripPlanerForm, onCloseTripPlanerForm }) => {
    const [fromLocation, setFromLocation] = useState('');
    const [toLocation, setToLocation] = useState('');
    

    const handleSubmit = (e) => {
        e.preventDefault();
        // Handle form submission logic here
        console.log('From:', fromLocation);
        console.log('To:', toLocation);
        // You can also call a function to handle the trip planning here
        // e.g., planTrip(fromLocation, toLocation);
    };
    if (!isOpenTripPlanerForm) return null;

    return (
        <div style={styles.modalOverlay} onClick={onCloseTripPlanerForm}>
        <div style={styles.container} onClick={(e) => e.stopPropagation()}>
            <div style={styles.header}>
                <h2 style={styles.title}>EV Trip Planner</h2>
                <button style={styles.closeButton} onClick={onCloseTripPlanerForm}>
                    &times;
                </button>
            </div>
         <div style={styles.formContainer}>
    <form onSubmit={handleSubmit}>
        <div style={styles.inputGroup}>
            <label htmlFor="from">From:</label>
            <input
                type="text"
                id="from"
                value={fromLocation}
                onChange={(e) => setFromLocation(e.target.value)}
                style={styles.input}
                required
            />
        </div>
        <div style={styles.inputGroup}>
            <label htmlFor="to">Destination:</label>
            <input
                type="text"
                id="to"
                value={toLocation}
                onChange={(e) => setToLocation(e.target.value)}
                style={styles.input}
                required
            />
        </div>
        <button type="submit" style={styles.submitButton}>
           Search
        </button>
    </form>

    <div className="filter-sub-title">
    <p>Coming Soon</p>

    <div style={styles.comingSoonRadio}>
    <div style={styles.checkboxContainer}>
        <input id="checkbox-1" style={styles.checkboxCustom} type="checkbox" defaultChecked />
        <label htmlFor="checkbox-1" style={styles.checkboxCustomLabel}>Avoid Tolls</label>
    </div>
    <div style={styles.checkboxContainer}>
        <input id="checkbox-2" style={styles.checkboxCustom} type="checkbox" />
        <label htmlFor="checkbox-2" style={styles.checkboxCustomLabel}>Avoid Highways</label>
    </div>
    <div style={styles.checkboxContainer}>
        <input id="checkbox-3" style={styles.checkboxCustom} type="checkbox" />
        <label htmlFor="checkbox-3" style={styles.checkboxCustomLabel}>Avoid Ferries</label>
    </div>
</div>
</div>
</div>

        </div>
    </div>
    );
};

export default TripPlanerForm;

// Styles remain unchanged
const styles = {
    modalOverlay: {
        position: 'fixed',
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        backgroundColor: 'rgba(0, 0, 0, 0.5)',
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        zIndex: 9999,
    },

    formContainer: {
        margin:'20px 14px 0px 17px'
    },
    containerTripForm: {
        display: 'flex',
        flexDirection: 'column',
        width: '400px',
        height: '600px',
        backgroundColor: '#fff',
        // borderRadius: '8px',
        overflow: 'hidden',
    },
    headerTripForm: {
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        backgroundColor: '#738677',
        padding: '0px 20px',
        borderBottom: '1px solid #ccc',
    },
    titleTripForm: {
        margin: 0,
        fontSize: '20px',
        color: '#333',
    },
    closeButtonTripForm: {
        background: 'none',
        border: 'none',
        fontSize: '24px',
        cursor: 'pointer',
        color: '#333',
    },
    textContainerTripForm: {
        flex: 1,
        display: 'flex',
        flexDirection: 'column',
        justifyContent: 'center',
        color: "black",
        backgroundColor: "white",
    },
    benefitsList: {
        listStyleType: 'none',
        paddingLeft: '0',
    },
    buttonTripForm: {
        width: '100%',
        padding: '10px',
        borderRadius: '4px',
        border: 'none',
        backgroundColor: '#738677',
        color: '#fff',
        fontSize: '16px',
        cursor: 'pointer',
        marginTop: '20px',
    },
    inputGroupTripForm: {
        marginBottom: '15px',
    },
    inputTripForm: {
        width: '100%',
        padding: '10px',
        borderRadius: '4px',
        border: '1px solid #ccc',
        height: '40px', // Set a fixed height to maintain single line
        boxSizing: 'border-box', // Ensure padding is included in the height
    },
    submitButtonTripForm: {
        // width: '100%',
        padding: '10px',
        borderRadius: '4px',
        border: 'none',
        backgroundColor: '#738677',
        color: '#fff',
        fontSize: '16px',
        cursor: 'pointer',
    },
    
    comingSoonRadio: {
        display: 'flex',
        flexDirection: 'column', /* Stack checkboxes vertically */
    },
    comingSoonRadio: {
        display: 'flex',
        flexDirection: 'column', /* Stack checkboxes vertically */
    },
    checkboxContainer: {
        display: 'flex',
        alignItems: 'center', /* Align checkbox and label vertically */
        marginBottom: '10px', /* Space between each checkbox */
    },
    checkboxCustom: {
        marginRight: '8px', /* Space between checkbox and label */
        width: '20px', /* Optional: adjust width of the checkbox */
        height: '20px', /* Optional: adjust height of the checkbox */
    },
    checkboxCustomLabel: {
        color: '#333', /* Label text color */
        fontSize: '16px', /* Label font size */
    },

    
};
