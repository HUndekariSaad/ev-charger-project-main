import React from 'react'

const LegendComponent = () => {
  return (
    <div>
      <h1>
        Trip Planner Guide & Tips 
      </h1>
      <p>We've launched an all-new help center to better serve your
needs, which includes updated Trip Planner resources. Feel
free to check out our guide:</p>


<p>Trip Planner is back in action! This newly rebuilt Trip Planner has a lot of new requested
features so we'll go through how to use them here. Please send any feedback or bug reports by
clicking the Menu dropdown and Submit Feedback.</p>

<p>Notice: To create or edit trips, we require your screen to be a minimum of 1200px wide.</p>


<p>This is the optimal minimum resolution because with the Trip Planner bar fixed to the right, you
need enough real estate to view and browse the map, while also looking at location details on
the left.
</p>

<p>We have made updates to make the Trip Planner responsive for mobile & tablet devices, so
you can still view your previously planned trips on the go.</p>


<p>To begin, please add your Starting Location and Destination.</p>


<p>The map will automatically route your driving directions and populate the map with charging
stations along your route.</p>

<p>Please keep in mind, your filters still apply!! You may open up your filter settings and update
them to refresh the map markers as per usual.</p>


    </div>
  )
}

export default LegendComponent
